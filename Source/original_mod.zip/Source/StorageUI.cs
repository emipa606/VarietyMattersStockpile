﻿using RimWorld;
using System.Reflection;
using UnityEngine;
using Verse;
using HarmonyLib;

namespace VarietyMattersStockpile
{
    [HarmonyPatch]
    public class StorageUI
    {
        //Stack Limits
        static string dupBuffer = "";
        static string sizeBuffer = "";
        static StorageSettings oldSettings = null;
        private const int max = 9999999;

        private static ITab_Storage currentTab = null;

        [HarmonyPatch(typeof(ITab_Storage), "FillTab")]
        public static void Prefix(ITab_Storage __instance)
        {
            currentTab = __instance;
        }

        [HarmonyPatch(typeof(ITab_Storage), "FillTab")]
        public static void Postfix()
        {
            currentTab = null;
        }

        [HarmonyPatch(typeof(ThingFilterUI), "DoThingFilterConfigWindow")]
        [HarmonyPrefix]
        public static void ExpandWindow(ref Rect rect)
        {
            ITab_Storage tab = currentTab;
            if (tab == null)
                return;

            rect.yMin += 55f;
        }

        [HarmonyPatch(typeof(ThingFilterUI), "DoThingFilterConfigWindow")]
        [HarmonyPostfix]
        public static void AddFilters(ref Rect rect)
        {
            ITab_Storage tab = currentTab;
            if (tab == null)
                return;

            IStoreSettingsParent storeSettingsParent = (IStoreSettingsParent)typeof(ITab_Storage).GetProperty("SelStoreSettingsParent", BindingFlags.NonPublic | BindingFlags.Instance).GetGetMethod(true).Invoke(tab, new object[0]);
            StorageSettings settings = storeSettingsParent.GetStoreSettings();
            ISlotGroupParent slotGroupParent = settings.owner as ISlotGroupParent;
            if (slotGroupParent == null)
                return;
            StorageLimits limitSettings = StorageLimits.GetLimitSettings(settings);
            //Text.Font = GameFont.Tiny;

            //Duplicates
            int dupLimit = limitSettings.dupStackLimit;
            bool limitDuplicates = dupLimit != -1;
            Widgets.CheckboxLabeled(new Rect(rect.xMin, rect.yMin - 50f, rect.width / 2 - 45f, 20f), "Duplicates", ref limitDuplicates, false);
            if (limitDuplicates)
            {
                if (oldSettings != settings)
                    dupBuffer = dupLimit.ToString();

                Widgets.TextFieldNumeric<int>(new Rect(rect.xMin + (rect.width / 2) - 40f, rect.yMin - 50f, rect.width / 2 - 115f, 20f), ref dupLimit, ref dupBuffer, 1, max);
            }
            else
            {
                dupLimit = -1;
            }

            //Stack Limit
            int sizeLimit = limitSettings.stackSizeLimit;
            bool hasLimit = sizeLimit != -1;
            Widgets.CheckboxLabeled(new Rect(rect.xMin + (rect.width / 2) - 5f, rect.yMin - 50f, rect.width / 2 - 45f, 20f), "Stack size", ref hasLimit, false);
            if (hasLimit)
            {
                if (oldSettings != settings)
                    sizeBuffer = sizeLimit.ToString();

                Widgets.TextFieldNumeric<int>(new Rect(rect.xMin + (rect.width / 2) + 95f, rect.yMin - 50f, rect.width / 2 - 105f, 20f), ref sizeLimit, ref sizeBuffer, 1, max);
            }
            else
            {
                sizeLimit = -1;
            }

            //Refill
            float cellFillPercentage = limitSettings.cellFillPercentage * 100;
            int numCells = slotGroupParent.AllSlotCellsList().Count;
            int numCellsStart = Mathf.CeilToInt((100 - cellFillPercentage) / 100 * numCells);
            bool startFilling = limitSettings.needsFilled;
            string label;
            switch (numCellsStart)
            {
                case 0:
                    label = "Always keep fully stocked";
                    break;
                case 1:
                    label = "Start refilling when 1 space is available";
                    break;
                default:
                    if (numCellsStart == numCells)
                    {
                        label = "Start refilling when empty";
                    }
                    else
                    {
                        label = "Start refilling when " + numCellsStart.ToString("N0") + " spaces are available";
                    }
                    break;
            }

            cellFillPercentage = Widgets.HorizontalSlider(new Rect(0f, rect.yMin - 80f, rect.width, 36f), cellFillPercentage, 0f, 100f, false, label);
            if (cellFillPercentage < 100 && limitSettings.cellsFilled != numCells)
            {
                Widgets.CheckboxLabeled(new Rect(rect.xMin + rect.width * 0.6f, rect.yMin - 110f, rect.width * .30f, 20f), "Fill now", ref startFilling, false);
            }
            //Update Settings
            oldSettings = settings;
            limitSettings.dupStackLimit = dupLimit;
            limitSettings.stackSizeLimit = sizeLimit;
            limitSettings.cellFillPercentage = cellFillPercentage / 100f;
            limitSettings.needsFilled = startFilling;
            StorageLimits.SetLimitSettings(settings, limitSettings);
            //Log.Message("Set stack size limit of " + limitSettings.stackSizeLimit);
        }
    }
}
