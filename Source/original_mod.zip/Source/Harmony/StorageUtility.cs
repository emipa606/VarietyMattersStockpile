﻿using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;
using Verse.AI;

namespace VarietyMattersStockpile
{
    [HarmonyPatch]
    public class Patch_StoreUtility
    {
        [HarmonyPatch(typeof(StoreUtility), "NoStorageBlockersIn")]
        public static bool Postfix(bool __result, IntVec3 c, Map map, Thing thing)
        {
            if (__result)
            {
                SlotGroup slotGroup = c.GetSlotGroup(map);
                if (slotGroup == null)
                {
                    return __result;
                }
                //Log.Message("Get Limit Settings");
                StorageLimits limitSettings = StorageLimits.GetLimitSettings(slotGroup.Settings);
                if (!limitSettings.needsFilled && limitSettings.cellFillPercentage < 1)
                {
                    return false;
                }

                int sizeLimit = limitSettings.stackSizeLimit;
                if (sizeLimit > 0 && sizeLimit < thing.def.stackLimit)
                {
                    bool newStack = true;
                    __result = StackSpaceAvailable(ref newStack, sizeLimit, c, map, thing);
                    if (!newStack || limitSettings.dupStackLimit <= 0)
                        return __result;
                    else
                        return !DupLimitReached(slotGroup, c, map, thing, limitSettings.dupStackLimit, sizeLimit);
                }
                return !(limitSettings.dupStackLimit > 0 && DupLimitReached(slotGroup, c, map, thing, limitSettings.dupStackLimit, thing.def.stackLimit));
            }
            return __result;
        }
        
        [HarmonyPatch(typeof(StoreUtility), "TryFindBestBetterStoreCellFor")]
        public static void Prefix(Thing t, ref StoragePriority currentPriority)
        {
            if (t.stackCount > StorageLimits.CalculateSizeLimit(t) )
            {
                currentPriority = StoragePriority.Low;
            }
        }
        
        public static bool StackSpaceAvailable(ref bool firstStack, int sizeLimit, IntVec3 c, Map map, Thing thing)
        {
            //Log.Message(thing.Label + "'s stack size limit is " + sizeLimit);
            List<Thing> storedItems = map.thingGrid.ThingsListAt(c);
            int numStacks = 0;
            for (int i = 0; i < storedItems.Count; i++)
            {
                Thing thing2 = storedItems[i];
                if (thing == thing2)
                {
                    numStacks += 1;
                }
                else if (thing2.def.EverStorable(false) && thing.CanStackWith(thing2))
                {
                    numStacks += 1;
                    if (thing2.stackCount < sizeLimit * numStacks)
                    {
                        firstStack = false;
                        return true;
                    }
                }
            }
            firstStack = numStacks == 0;
            return firstStack;
        }

        public static bool DupLimitReached(SlotGroup slotGroup, IntVec3 c, Map map, Thing t, int dupLimit, int sizeLimit)
        {
            // Log.Message("Checking for duplicates");
            int duplicates = 0;
            foreach (Thing storedItem in slotGroup.HeldThings)
            {
                if (storedItem.def.EverStorable(false) &&
                   (t.CanStackWith(storedItem) || (ModSettings_VarietyStockpile.limitNonStackables && t.def.stackLimit == 1 && t.def == storedItem.def)))
                {
                    if (storedItem.Position == c && storedItem.stackCount < sizeLimit)
                    {
                        return false;
                    }
                    duplicates++;
                    if (duplicates >= dupLimit)
                        return true;
                }
            }
            if (ModSettings_VarietyStockpile.checkReservations && map.reservationManager != null)
            {
                List<ReservationManager.Reservation> allReservations = map.reservationManager.ReservationsReadOnly;
                if (allReservations != null)
                {
                    for (int i = 0; i < allReservations.Count; i++)
                    {
                        ReservationManager.Reservation reservation = allReservations[i];
                        Job job = reservation.Job;
                        if (reservation != null && job != null && job.targetA.Thing != null)
                        {
                            SlotGroup slotGroup2 = null;
                            Thing reservedItem = job.targetA.Thing;
                            if (job.def == JobDefOf.HaulToCell)
                            {
                                Map map2 = reservedItem.Map ?? reservedItem.MapHeld;
                                if (map2 != null)
                                    slotGroup2 = StoreUtility.GetSlotGroup(job.targetB.Cell, map2);
                            }
                            else if (job.def == JobDefOf.HaulToContainer && job.targetB.Thing != null)
                            {   
                                slotGroup2 = StoreUtility.GetSlotGroup(job.targetB.Thing.Position, job.targetB.Thing.Map);
                            }
                            if (slotGroup2 != null && slotGroup == slotGroup2 && t != reservedItem && reservedItem.def.EverStorable(false) &&
                               (t.CanStackWith(reservedItem) || (ModSettings_VarietyStockpile.limitNonStackables && t.def.stackLimit == 1 && t.def == reservedItem.def)))
                            {
                                duplicates++;
                                if (duplicates >= dupLimit)
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }

            }
            return false;
        }
    }
}
              