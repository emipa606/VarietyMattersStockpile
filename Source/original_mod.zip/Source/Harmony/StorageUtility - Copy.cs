﻿using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;
using Verse.AI;

namespace VarietyMattersStockpile
{
    [HarmonyPatch]
    public class Patch_StoreUtility
    {
        [HarmonyPatch(typeof(StoreUtility), "NoStorageBlockersIn")]
        public static bool Postfix(bool __result, IntVec3 c, Map map, Thing thing)
        {
            if (__result)
            {
                SlotGroup slotGroup = c.GetSlotGroup(map);
                if (slotGroup == null)
                {
                    return __result;
                }
                //Log.Message("Get Limit Settings");
                StorageLimits limitSettings = StorageLimits.GetLimitSettings(slotGroup.Settings);
                if (!limitSettings.needsFilled && limitSettings.cellFillPercentage < 1)
                {
                    return false;
                }

                bool firstStack = true;
                if (limitSettings.dupStackLimit > 0 && DupLimitReached(slotGroup, map, thing, limitSettings.dupStackLimit, ref firstStack))
                {
                    return false;
                }
                else if (firstStack)
                {
                    return __result;
                }

                int sizeLimit = limitSettings.stackSizeLimit;
                if (sizeLimit > 0 && sizeLimit < thing.def.stackLimit)
                {
                    //Log.Message("Checking for available stacking space");
                    return StackSpaceAvailable(sizeLimit, c, map, thing);
                }
            }
            return __result;
        }

        [HarmonyPatch(typeof(StoreUtility), "TryFindBestBetterStoreCellFor")]
        public static void Prefix(Thing t, ref StoragePriority currentPriority)
        {
            if (t.stackCount > StorageLimits.CalculateSizeLimit(t))
            {
                currentPriority = StoragePriority.Low;
            }
        }

        public static bool StackSpaceAvailable(int sizeLimit, IntVec3 c, Map map, Thing thing)
        {
            //Log.Message(thing.Label + "'s stack size limit is " + sizeLimit);
            List<Thing> storedItems = map.thingGrid.ThingsListAt(c);
            for (int i = 0; i < storedItems.Count; i++)
            {
                Thing thing2 = storedItems[i];
                if (thing != thing2 && thing2.def.EverStorable(false) && thing.CanStackWith(thing2))
                {
                    //Log.Message(thing.Label + " already has a stack present");
                    if (thing2.stackCount < sizeLimit)
                        return true;
                }
            }
            return false;
        }

        public static bool DupLimitReached(SlotGroup slotGroup, Map map, Thing t, int dupLimit, ref bool firstStack)
        {
            // Log.Message("Checking for duplicates");
            int duplicates = 0;
            foreach (Thing storedItem in slotGroup.HeldThings)
            {
                if (t != storedItem && storedItem.def.EverStorable(false) &&
                   (t.CanStackWith(storedItem) || (ModSettings_VarietyStockpile.limitNonStackables && t.def.stackLimit == 1 && t.def == storedItem.def)))
                {
                    if (storedItem.stackCount >= StorageLimits.CalculateSizeLimit(storedItem))
                    {
                        duplicates++;
                    }
                    if (duplicates >= dupLimit)
                    {
                        return true;
                    }
                    firstStack = false;
                }
            }
            if (ModSettings_VarietyStockpile.checkReservations && map.reservationManager != null)
            {
                List<ReservationManager.Reservation> allReservations = map.reservationManager.ReservationsReadOnly;
                if (allReservations != null)
                {
                    for (int i = 0; i < allReservations.Count; i++)
                    {
                        ReservationManager.Reservation reservation = allReservations[i];
                        Job job = reservation.Job;
                        if (reservation != null && job != null && job.targetA.Thing != null)
                        {
                            SlotGroup slotGroup2 = null;
                            Thing reservedItem = job.targetA.Thing;
                            if (job.def == JobDefOf.HaulToCell)
                            {
                                Map map2 = reservedItem.Map ?? reservedItem.MapHeld;
                                if (map2 != null)
                                    slotGroup2 = StoreUtility.GetSlotGroup(job.targetB.Cell, map2);
                            }
                            else if (job.def == JobDefOf.HaulToContainer && job.targetB.Thing != null)
                            {   
                                slotGroup2 = StoreUtility.GetSlotGroup(job.targetB.Thing.Position, job.targetB.Thing.Map);
                            }
                            if (slotGroup2 != null && slotGroup == slotGroup2 && t != reservedItem && reservedItem.def.EverStorable(false) &&
                               (t.CanStackWith(reservedItem) || (ModSettings_VarietyStockpile.limitNonStackables && t.def.stackLimit == 1 && t.def == reservedItem.def)))
                            {
                                duplicates++;
                                if (duplicates >= dupLimit)
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }

            }
            return false;
        }
    }
}
              